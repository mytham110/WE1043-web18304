// nhap a tu ban phim
let a = prompt("Nhap so nguyen a:");
//let a1 = parseInt
//nhap b tu ban phim
let b = prompt("Nhap so nguyen b:")
//let b1 = parseInt
let c = parseInt(a)+parseInt(b);
document.write(c);
console.log(c);